export interface IUser {
	firstName: string
	lastName: string
	id: string
	username: string
	photoUrl: string
	inviteCode: string
}
