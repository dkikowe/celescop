export function LoginTitle() {
	return (
		<h1
			className='w-full text-center text-white'
			style={{
				background: 'linear-gradient(90deg, #27448D 0%, #0B1327 100%)',
			}}
		>
			Вход
		</h1>
	)
}
