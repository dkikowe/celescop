export function HomeIcon() {
	return <img src='/home.png' width={40} height={40} className='max-[350px]:w-[30px] max-[350px]:h-[30px] aspect-square' />
}
